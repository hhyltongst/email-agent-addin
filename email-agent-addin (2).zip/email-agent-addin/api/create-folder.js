export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { folderName } = req.body;
  if (!folderName) return res.status(400).json({ error: 'folderName required' });

  // Get Microsoft Graph access token using client credentials
  const tenantId = process.env.MS_TENANT_ID;
  const clientId = process.env.MS_CLIENT_ID;
  const clientSecret = process.env.MS_CLIENT_SECRET;
  const userEmail = process.env.MS_USER_EMAIL; // the mailbox owner's email

  if (!tenantId || !clientId || !clientSecret || !userEmail) {
    // Graceful fallback if MS credentials not configured
    return res.status(200).json({
      success: true,
      message: `Folder "${folderName}" noted! To auto-create folders, add MS_TENANT_ID, MS_CLIENT_ID, MS_CLIENT_SECRET, MS_USER_EMAIL to your Vercel env vars.`
    });
  }

  try {
    // Get token
    const tokenRes = await fetch(`https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'client_credentials',
        client_id: clientId,
        client_secret: clientSecret,
        scope: 'https://graph.microsoft.com/.default'
      })
    });
    const tokenData = await tokenRes.json();
    const accessToken = tokenData.access_token;
    if (!accessToken) throw new Error('Could not get access token');

    // Create folder via Graph API
    const graphRes = await fetch(`https://graph.microsoft.com/v1.0/users/${userEmail}/mailFolders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`
      },
      body: JSON.stringify({ displayName: folderName })
    });

    if (!graphRes.ok) {
      const err = await graphRes.json();
      throw new Error(err.error?.message || 'Graph API error');
    }

    const folder = await graphRes.json();
    return res.status(200).json({ success: true, folderId: folder.id, folderName: folder.displayName });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
}
